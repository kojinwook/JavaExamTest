public class Exam2 {
    public static void main(String[] args) {
        // 높이 : 3
        int y =3;
        for(int i= 1; i<= y; i++){for(int j = 1; j<=i; j++){
            System.out.print("*");
        }
            System.out.println();
        }
        /*

         *
         ***
         *****

         */

        // 높이 : 5
        int z =5;
        for(int k= 1; k<= z; k++){for(int w = 1; w<=k; w++){
            System.out.print("*");
        }
            System.out.println();
        }
        // 출력

        /*

         *
         ***
         *****
         *******
         *********

         */

        // 높이 : 7
        int q =7;
        for(int x= 1; x<= q; x++){for(int c = 1; c<=x; c++){
            System.out.print("*");
        }
            System.out.println();
        }
        // 출력

        /*

         *
         ***
         *****
         *******
         *********
         ***********
         *************

         */

    }
}
